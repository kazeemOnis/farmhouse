module.exports = {
  database:"mongodb://kazonis:kazman3@ds263367.mlab.com:63367/farmhouse",
  secret: "yoursecret",
  email: "noreplyfarmhouse@gmail.com",
  password: "Farmhouse1234",
  appID: "1012421285571507",
  appID1: '568952740154184',
  appSecret: "4ef871bfd15901a4e164350fed314f61",
  appSecret1:"591d0b3c3918fb0f4f02c91b6102d864", 
  url: "http://localhost:3000/investor/login/facebook/callback",
  url1: "http://localhost:3000/farmer/login/facebook/callback"
};