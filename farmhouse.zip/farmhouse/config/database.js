module.exports = {
  database:"mongodb://kazonis:kazman3@ds263367.mlab.com:63367/farmhouse",
  secret: "yoursecret",
  email: "noreplyfarmhouse@gmail.com",
  password: "Farmhouse1234"
};